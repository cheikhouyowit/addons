# Copyright 2018 Stanislav Krotov <https://it-projects.info/team/ufaks>
# License MIT (https://opensource.org/licenses/MIT).

from . import test_odoo_backup_sh_auto_rotation
from . import test_odoo_backup_sh_ui
