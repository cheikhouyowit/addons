`1.0.2`
-------

- **Fix:** Dashboard error when additional modules are not in module list

`1.0.1`
-------

- **Improvement:** better title for total remote usage graph

`1.0.0`
-------

- Init version
