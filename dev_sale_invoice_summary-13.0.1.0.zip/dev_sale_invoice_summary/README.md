Sale/Invoice Summary Report:
=========================================================

Go to Setting / apps and search "Sale/Invoice / Sale/Invoice Summary Report" and Install

And, you are done with installation. Congratulations!
